## OpenVINO Training Extensions
[Reference](https://github.com/openvinotoolkit/training_extensions/tree/releases/1.5.0)

## How to install:
  ```sh
  python3.10 -m venv venv_otx
  pip install -U pip wheel
  pip install -r requirements.txt
  ```

## Practice #1 - Classification
 - [Link](https://openvinotoolkit.github.io/training_extensions/1.5.0/guide/tutorials/base/how_to_train/classification.html)

## Practice #2 - Object Detection
 - [Link](https://openvinotoolkit.github.io/training_extensions/1.5.0/guide/tutorials/base/how_to_train/detection.html)
